<div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
    <h6 class="dropdown-header">
        Alerts Center
    </h6>
    <div id="notification">
        
    </div>
    <a class="dropdown-item text-center small text-gray-500" href="{{url('/list_notifications?status=pending')}}">Show All Alerts</a>
</div>
